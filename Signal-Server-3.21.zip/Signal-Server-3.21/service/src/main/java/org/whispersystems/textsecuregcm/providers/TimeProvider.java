package org.whispersystems.textsecuregcm.providers;

public class TimeProvider {
  public long getCurrentTimeMillis() {
    return System.currentTimeMillis();
  }
}
