package org.whispersystems.textsecuregcm.storage;

public interface PubSubAddress {
  public String serialize();
}
