package org.whispersystems.textsecuregcm.util;

public class Constants {

  public static final String METRICS_NAME = "textsecure";

}
